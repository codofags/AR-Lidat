using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RBoff : MonoBehaviour
{
    public Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        
    }
     void OnCollisionEnter(Collision collision)
    {
        rb.isKinematic=true;
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
